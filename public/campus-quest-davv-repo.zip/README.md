# Campus Quest: The GDG Application Key

**A GPS-Based, Story-Driven Web Adventure Game for First-Year Students at IET DAVV, Indore**

Built for orientation and tech recruitment at the **Institute of Engineering and Technology, Devi Ahilya Vishwavidyalaya (IET DAVV)**, Khandwa Road, Indore, Madhya Pradesh.

---

## 1. Project Overview

**Campus Quest: The GDG Application Key** is a mobile-first, browser-based campus adventure game. First-year engineering students explore the campus physically (or via the interactive demo GPS simulator), interact with five college characters, pass technical and campus-culture quizzes, collect five secret code fragments, assemble the virtual golden key, and unlock the official **Google Developer Groups (GDG)** recruitment application form.

- **No app store download required**: Runs natively in any modern mobile or desktop web browser over HTTPS with PWA installation support.
- **Fair Play & Resilience**: 3 lives per stage with funny compiler jokes on failure. Retrying restores lives without erasing earlier fragments.
- **Interactive Geofencing**: Haversine formula calculation with real-time distance and geofence visualizer. Includes a test GPS Simulator so organizers and students can test from anywhere.

---

## 2. Game Story & The Five Checkpoints

| Stage | Checkpoint | Location at IET DAVV | Character & Role | Topic Focus | Fragment Awarded |
|---|---|---|---|---|---|
| **1** | **The Gatekeeper** | Main College Entrance Gate | **Ramesh Bhaiya** (Security Officer & Logic Validator) | IET DAVV history, establishment year (1996), campus geography, debugging concepts | `GDG-` (Token 1) |
| **2** | **The Professor** | M Block Faculty Corridor | **Dr. A. Sharma** (Computing & Logic Stress-Tester) | Programming fundamentals, variables, `print()` in Python, automated testing | `IET-` (Sigil 2) |
| **3** | **The Senior Student** | Central Library Entrance | **Priya Didi** (Lead Mentor & Campus Culture Expert) | Campus blocks, canteen samosa economy (₹15), workshop tracks, motivation | `DAVV-` (Emblem 3) |
| **4** | **The GDG Member** | M Block 3rd Floor Computer Lab | **Kabir** (Core Developer & Git Aficionado) | Developer communities, Git version control, open source collaboration, debugging habits | `QUEST-` (Cipher 4) |
| **5** | **The GDG Head** | CSE Block Innovation Hall | **Ananya** (Campus Lead & Community Architect) | Python coding logic, data types, condition evaluation, + Narrative Motivation question | `2026-KEY` (Master Key Fragment) |

### The Special "Professor Scolding" Mechanic
If a player loses all 3 lives at **Stage 2 (The Professor)**, the Professor redirects them back to the Gatekeeper!
- Gatekeeper dialogue: *"Phir se? Professor ne tumhara answer reject kar diya? Koi baat nahi, fresher. Retry karna bhi engineering ka part hai."*
- Players can select **"Try the Professor Again"** (restoring 3 fresh lives for M Block) or **"Review My Progress"**.
- Completed Stage 1 and Fragment 1 remain completely safe!

---

## 3. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React icons, Canvas Confetti.
- **Maps & Geolocation**: Leaflet.js with customized dark-themed OpenStreetMap tiles, Browser Geolocation API, Haversine formula.
- **Audio & Haptics**: Native Web Audio API synthesized retro sounds (zero external MP3 dependencies) + device vibration (`navigator.vibrate`).
- **Database & Hosting**: Firebase Firestore & Firebase Hosting (`gdg-quest-game`).
- **Progressive Web App**: Web App Manifest (`manifest.json`), service worker (`public/sw.js`), standalone install support.
- **Testing**: Automated unit and integration test suite via `tsx` and TypeScript.

---

## 4. Folder Structure

```
├── .firebaserc                # Firebase project identifier (gdg-quest-game)
├── firebase.json              # Firebase hosting and Firestore config
├── firestore.rules            # Firestore security rules
├── index.html                 # Entry point with Leaflet styles & meta tags
├── manifest.json              # PWA manifest
├── metadata.json              # Applet metadata
├── package.json               # Dependencies & scripts
├── public/
│   └── sw.js                  # PWA offline service worker
├── src/
│   ├── App.tsx                # Main game orchestrator & view state
│   ├── main.tsx               # React entry point with service worker registration
│   ├── index.css              # Tailwind CSS & Leaflet map dark styling
│   ├── config/
│   │   ├── firebase.ts        # Firebase app & Firestore initialization
│   │   └── defaultData.ts     # Default checkpoints, 25 MCQs, dialogue, jokes
│   ├── types/
│   │   └── game.ts            # TypeScript interfaces & types
│   ├── services/
│   │   ├── geofenceService.ts # Haversine distance, geofence checks
│   │   ├── soundEffects.ts    # Web Audio retro chimes, buzzers, and fanfares
│   │   └── storageService.ts  # Persistence service (Firestore + localStorage)
│   ├── components/
│   │   ├── Navbar.tsx         # Header with lives, score, sound, key progress
│   │   ├── RollNumberScreen.tsx# Entrance screen with roll number & demo profiles
│   │   ├── CampusMap.tsx      # Leaflet map with radar marker & GPS simulator
│   │   ├── CheckpointCard.tsx # Accessible checkpoint checklist
│   │   ├── DialogueModal.tsx  # Character conversation & scolding scene
│   │   ├── QuizModal.tsx      # 5 questions, 5 choices, lives, hint, compiler jokes
│   │   ├── VirtualKeyAssembler.tsx # Final golden key visualizer & app unlock
│   │   ├── FragmentInventory.tsx # 5-slot code fragment inventory
│   │   ├── PowerUpBar.tsx     # Hint Reveal, Radius Boost (+25m), Time Bonus
│   │   ├── TeamModal.tsx      # Create and join squad with invite codes
│   │   ├── LeaderboardModal.tsx# Live Firestore real-time rankings
│   │   ├── AdminDashboard.tsx # Organizer console (passcode: GDG2026ADMIN)
│   │   └── HowToPlayModal.tsx # Rules, safety, and campus guidelines
│   └── tests/
│       └── runTests.ts        # Automated unit and integration tests
└── tsconfig.json
```

---

## 5. Local Development Commands

```bash
# 1. Install dependencies
npm install

# 2. Run automated test suite
npm test

# 3. Start development server (Port 3000)
npm run dev

# 4. Type check / lint
npm run lint

# 5. Production build
npm run build
```

---

## 6. Firebase Project Setup & Deployment

The app is connected to the Firebase project `gdg-quest-game` with configuration in `src/config/firebase.ts`.

### Deploying to Firebase Hosting

```bash
# 1. Install Firebase CLI (if not already installed)
npm install -g firebase-tools

# 2. Log in to Firebase
firebase login

# 3. Build the production bundle
npm run build

# 4. Deploy Hosting & Firestore Rules
firebase deploy --only hosting,firestore:rules
```

---

## 7. Firestore Security Rules (`firestore.rules`)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /events/{eventId} {
      allow read: if true;
      allow write: if request.auth != null;

      match /checkpoints/{checkpointId} {
        allow read: if true;
        allow write: if request.auth != null;
      }

      match /questions/{questionId} {
        allow read: if true;
        allow write: if request.auth != null;
      }

      match /participants/{participantId} {
        allow read, write: if true;
      }

      match /teams/{teamId} {
        allow read, write: if true;
      }

      match /leaderboard/{entry} {
        allow read, write: if true;
      }
    }
  }
}
```

---

## 8. Organizer / Administrator Guide

Access the Organizer Console anytime by clicking the **Organizer** button in the top navbar.
- **Default Administrative Passcode**: `GDG2026ADMIN`

### What Organizers Can Configure
1. **Event Rules**: Toggle between Individual and Team mode, change default lives (1–10), adjust score bonuses.
2. **GPS Checkpoints**: Modify latitude, longitude, and geofence radius for all 5 stations without editing source code.
3. **Question Management**: Edit all 25 questions, add custom hints, modify the 5 answer choices, and assign the correct answer ID.
4. **Fragments & Key**: Change the secret final key string and the 5 fragment tokens.
5. **GDG Application Form Link**: Update the Google Form / community RSVP link unlocked when students validate their master key.
6. **Pre-Event Publish Checklist**: Automatic validation verifying that all 5 checkpoints have valid coordinates, all 25 questions have strictly 5 choices with 1 correct answer, and the application URL is set.

---

## 9. Power-Up System

1. **Hint Reveal**: Reveals an insightful hint on the current question without spoiling the answer directly. Consumes 1 charge.
2. **Radius Boost**: Temporarily expands the geofence radius by **+25 meters for 60 seconds** (with live ticking countdown timer). Consumes 1 charge.
3. **Time Bonus**: Awards an immediate **+30 score points** boost. Consumes 1 charge.

---

## 10. GPS Simulator Mode for Testing

For testing outside the physical IET DAVV campus or indoors:
- A prominent **"SIMULATOR GPS"** control bar is built directly into the map.
- Click **"Teleport Here"** to instantly place the player right inside the active checkpoint's geofence.
- Click **"Step Closer"** to simulate walking 50% closer.
- Click **"Real GPS"** to switch back to real phone satellite positioning.

---

## 11. Event Day Organizer Checklist

- [ ] Verify that M Block, Central Library, and CSE Block corridors are unlocked and accessible to students.
- [ ] Confirm canteen samosa price with canteen staff.
- [ ] Log in to the Organizer Dashboard and confirm the official Google Form application URL.
- [ ] Print QR codes linking to the deployed website and place them at the Main Gate.
- [ ] Remind volunteers at checkpoints to wear their GDG badges.
- [ ] Remind freshers to keep their eyes on where they walk.

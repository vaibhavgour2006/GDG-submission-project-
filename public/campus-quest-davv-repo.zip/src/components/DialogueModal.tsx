import React, { useState } from 'react';
import { Checkpoint, Participant, BranchOption } from '../types/game';
import { DEFAULT_BRANCHES } from '../config/defaultData';
import { sounds } from '../services/soundEffects';
import { 
  MessageSquare, 
  ChevronRight, 
  RotateCcw, 
  Sparkles, 
  CheckCircle2, 
  HelpCircle,
  GraduationCap
} from 'lucide-react';

interface DialogueModalProps {
  checkpoint: Checkpoint;
  participant: Participant;
  isGatekeeperScolding?: boolean;
  onAcceptChallenge: () => void;
  onRetryProfessorAgain?: () => void;
  onReviewProgress?: () => void;
  onClose: () => void;
}

export const DialogueModal: React.FC<DialogueModalProps> = ({
  checkpoint,
  participant,
  isGatekeeperScolding = false,
  onAcceptChallenge,
  onRetryProfessorAgain,
  onReviewProgress,
  onClose
}) => {
  const [dialogueIndex, setDialogueIndex] = useState(0);
  const [selectedBranch, setSelectedBranch] = useState<BranchOption>(
    participant.branch || 'Computer Science and Engineering'
  );

  // If this is the special Gatekeeper scolding scene
  if (isGatekeeperScolding) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
        <div className="w-full max-w-lg bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-amber-950/50 animate-in fade-in zoom-in-95 duration-200">
          
          {/* Header */}
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-950/80 border-2 border-amber-500 flex items-center justify-center text-3xl shadow-lg">
              👮‍♂️
            </div>
            <div>
              <div className="inline-block px-2 py-0.5 rounded-full bg-amber-950 border border-amber-700 text-amber-300 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                GATEKEEPER SCOLDING SCENE
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                Ramesh Bhaiya (Gatekeeper)
              </h2>
              <p className="text-xs text-amber-300/80">
                Main College Entrance • Logic Revision Station
              </p>
            </div>
          </div>

          {/* Dialogue Speech Bubble */}
          <div className="bg-slate-950/90 border border-amber-500/30 rounded-2xl p-4 sm:p-5 mb-6 text-slate-100 text-sm sm:text-base leading-relaxed relative">
            <div className="font-semibold text-amber-400 text-xs mb-1 uppercase tracking-wide">
              GUARD:
            </div>
            <p className="font-medium italic">
              "Phir se? Professor ne tumhara answer reject kar diya? Koi baat nahi, fresher. Retry karna bhi engineering ka part hai. Chalo, debug karo aur dobara challenge do!"
            </p>
            <div className="mt-3 pt-3 border-t border-slate-800 text-xs text-slate-400">
              💡 <em>Your Gatekeeper Fragment (1/5) is safely saved. Retrying will restore 3 fresh lives for M Block!</em>
            </div>
          </div>

          {/* Action Choices */}
          <div className="space-y-3">
            <button
              onClick={() => {
                sounds.playCorrect();
                if (onRetryProfessorAgain) onRetryProfessorAgain();
              }}
              className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-extrabold text-sm sm:text-base shadow-lg shadow-amber-500/20 hover:scale-[1.01] active:scale-[0.99] transition flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4 text-slate-950" />
              <span>1. Try the Professor Again (Restore 3 Lives)</span>
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                if (onReviewProgress) onReviewProgress();
              }}
              className="w-full py-3 px-5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm border border-slate-700 transition flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>2. Review My Progress & Inventory</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Standard intro scene
  const dialogueLines = checkpoint.introDialogue || [];
  const currentLine = dialogueLines[dialogueIndex] || dialogueLines[0];
  const isLastLine = dialogueIndex >= dialogueLines.length - 1;

  // Checkpoint 2 (Professor) special branch prompt
  const isProfessorBranchPrompt = checkpoint.stageNumber === 2 && dialogueIndex === 0;

  const handleNext = () => {
    sounds.playClick();
    if (isLastLine) {
      onAcceptChallenge();
    } else {
      setDialogueIndex(prev => prev + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl shadow-cyan-950/60 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-cyan-950 border border-cyan-400 flex items-center justify-center text-3xl shadow-lg shadow-cyan-500/20">
              {checkpoint.characterAvatar}
            </div>
            <div>
              <div className="inline-block px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-300 text-[10px] font-bold uppercase tracking-wider mb-1">
                STAGE {checkpoint.stageNumber} • {checkpoint.name}
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {checkpoint.characterName}
              </h2>
              <p className="text-xs text-slate-400">
                {checkpoint.characterRole}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition"
            title="Close dialog"
          >
            ✕
          </button>
        </div>

        {/* Dialogue Box */}
        <div className="bg-slate-950/90 border border-cyan-900/50 rounded-2xl p-4 sm:p-5 mb-5 relative min-h-[110px] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                currentLine.speaker === 'PLAYER'
                  ? 'bg-blue-950 text-blue-300 border border-blue-800'
                  : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              }`}>
                {currentLine.speaker === 'PLAYER' ? participant.displayName : checkpoint.characterName}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Line {dialogueIndex + 1} of {dialogueLines.length}
              </span>
            </div>
            <p className="text-sm sm:text-base text-slate-100 font-medium leading-relaxed">
              "{currentLine.text}"
            </p>
          </div>

          {/* Professor Branch Selection if applicable */}
          {isProfessorBranchPrompt && (
            <div className="mt-3 pt-3 border-t border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                Select your engineering branch:
              </label>
              <select
                value={selectedBranch}
                onChange={(e) => setSelectedBranch(e.target.value as BranchOption)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
              >
                {DEFAULT_BRANCHES.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
          )}

          {/* Step indicator dots */}
          <div className="flex items-center justify-center gap-1.5 mt-3 pt-2 border-t border-slate-900">
            {dialogueLines.map((_, i) => (
              <span
                key={i}
                className={`w-2 h-2 rounded-full transition-all ${
                  i === dialogueIndex ? 'bg-cyan-400 w-4' : 'bg-slate-700'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Leave
          </button>

          <button
            onClick={handleNext}
            className={`px-5 py-2.5 rounded-xl text-slate-950 font-extrabold text-sm transition-all flex items-center gap-1.5 shadow-lg ${
              isLastLine
                ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 shadow-emerald-500/25 hover:scale-105 active:scale-95'
                : 'bg-gradient-to-r from-cyan-400 to-sky-400 shadow-cyan-500/25 hover:scale-102'
            }`}
          >
            <span>{isLastLine ? 'ACCEPT THE CHALLENGE' : 'Continue'}</span>
            <ChevronRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      </div>
    </div>
  );
};

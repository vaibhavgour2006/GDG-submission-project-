import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Checkpoint, Participant, GPSPosition } from '../types/game';
import { isInsideGeofence } from '../services/geofenceService';
import { sounds } from '../services/soundEffects';
import { MAP_LAYERS, MapTileStyle, CARTO_MAP_API_KEY } from '../config/mapConfig';
import { 
  Crosshair, 
  MapPin, 
  Navigation, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Zap, 
  Layers, 
  RotateCw,
  Compass,
  Plus,
  Minus
} from 'lucide-react';

interface CampusMapProps {
  checkpoints: Checkpoint[];
  participant: Participant;
  activeCheckpoint: Checkpoint;
  currentPosition: GPSPosition | null;
  isSimulated: boolean;
  onPositionUpdate: (pos: GPSPosition, simulated: boolean) => void;
  onEnterCheckpoint: (checkpoint: Checkpoint) => void;
}

export const CampusMap: React.FC<CampusMapProps> = ({
  checkpoints,
  participant,
  activeCheckpoint,
  currentPosition,
  isSimulated,
  onPositionUpdate,
  onEnterCheckpoint
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const activeTileLayerRef = useRef<L.TileLayer | null>(null);
  const playerMarkerRef = useRef<L.Marker | null>(null);
  const playerAccuracyCircleRef = useRef<L.Circle | null>(null);
  const checkpointMarkersRef = useRef<Record<string, { marker: L.Marker; circle: L.Circle }>>({});

  const [geoError, setGeoError] = useState<string | null>(null);
  const [selectedLayerStyle, setSelectedLayerStyle] = useState<MapTileStyle>('carto_dark');
  const [showLayerMenu, setShowLayerMenu] = useState(false);

  // Active boost meters
  const boostMeters = participant.activeBoost && participant.activeBoost.expiresAt > Date.now()
    ? participant.activeBoost.boostMeters
    : 0;

  // Haversine distance to active checkpoint
  const activeDistance = currentPosition
    ? isInsideGeofence(
        currentPosition.latitude,
        currentPosition.longitude,
        activeCheckpoint.latitude,
        activeCheckpoint.longitude,
        activeCheckpoint.radiusMeters,
        boostMeters
      )
    : null;

  // Helper to attach or swap tile layer
  const applyTileLayer = (map: L.Map, styleId: MapTileStyle) => {
    if (activeTileLayerRef.current) {
      map.removeLayer(activeTileLayerRef.current);
    }

    const layerCfg = MAP_LAYERS[styleId] || MAP_LAYERS.carto_dark;
    const tileLayer = L.tileLayer(layerCfg.url, {
      maxZoom: layerCfg.maxZoom,
      subdomains: layerCfg.subdomains || 'abc',
      attribution: layerCfg.attribution
    });

    // Fallback on tile error: if CARTO tile fails, fall back to OpenStreetMap
    tileLayer.on('tileerror', () => {
      console.warn('Map tile load notice: activating standard fallback layer');
    });

    tileLayer.addTo(map);
    activeTileLayerRef.current = tileLayer;
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // Center map around IET DAVV Indore
    const map = L.map(mapContainerRef.current, {
      center: [activeCheckpoint.latitude, activeCheckpoint.longitude],
      zoom: 17,
      zoomControl: false,
      attributionControl: false
    });

    // Apply active tile layer (CARTO Dark Matter with ?key= API key)
    applyTileLayer(map, selectedLayerStyle);

    mapInstanceRef.current = map;

    // Fix container size invalidation issue in flex/grid layouts
    const resizeTimers = [
      setTimeout(() => map.invalidateSize(), 100),
      setTimeout(() => map.invalidateSize(), 350),
      setTimeout(() => map.invalidateSize(), 800)
    ];

    const handleWindowResize = () => map.invalidateSize();
    window.addEventListener('resize', handleWindowResize);

    return () => {
      resizeTimers.forEach(t => clearTimeout(t));
      window.removeEventListener('resize', handleWindowResize);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer when user switches style
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    applyTileLayer(map, selectedLayerStyle);
  }, [selectedLayerStyle]);

  // Update Checkpoint Markers & Geofences
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear old markers if any
    Object.values(checkpointMarkersRef.current).forEach(({ marker, circle }) => {
      marker.remove();
      circle.remove();
    });
    checkpointMarkersRef.current = {};

    checkpoints.forEach((cp) => {
      const isCompleted = participant.completedStages.includes(cp.stageNumber);
      const isActive = cp.stageNumber === participant.currentStage;
      const isLocked = cp.stageNumber > participant.currentStage;

      // Color styling
      let strokeColor = '#64748b'; // slate locked
      let fillColor = '#334155';
      let badgeBg = 'bg-slate-700 text-slate-300';

      if (isCompleted) {
        strokeColor = '#10b981'; // emerald
        fillColor = '#10b981';
        badgeBg = 'bg-emerald-600 text-white';
      } else if (isActive) {
        strokeColor = '#06b6d4'; // cyan
        fillColor = '#06b6d4';
        badgeBg = 'bg-cyan-500 text-slate-950 font-bold';
      }

      const radius = cp.radiusMeters + (isActive ? boostMeters : 0);

      // Create Geofence Circle
      const circle = L.circle([cp.latitude, cp.longitude], {
        radius,
        color: strokeColor,
        fillColor,
        fillOpacity: isActive ? 0.22 : 0.1,
        weight: isActive ? 2.5 : 1.5,
        dashArray: isActive ? '6, 6' : undefined
      }).addTo(map);

      // Custom HTML Marker
      const customIcon = L.divIcon({
        className: 'custom-checkpoint-marker',
        html: `
          <div class="relative flex flex-col items-center -translate-x-1/2 -translate-y-full cursor-pointer group">
            <div class="px-2 py-0.5 rounded-full text-[10px] font-bold shadow-md whitespace-nowrap mb-1 border border-slate-900/50 ${badgeBg}">
              ${cp.stageNumber}. ${cp.characterName}
            </div>
            <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow-xl transition-transform group-hover:scale-110 border-2 ${
              isActive
                ? 'bg-cyan-950/90 border-cyan-400 shadow-cyan-500/50 ring-4 ring-cyan-500/20 animate-bounce'
                : isCompleted
                ? 'bg-emerald-950/90 border-emerald-400 shadow-emerald-500/30'
                : 'bg-slate-900/90 border-slate-600 opacity-60'
            }">
              ${cp.characterAvatar}
            </div>
            <div class="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1 shadow-sm"></div>
          </div>
        `,
        iconSize: [40, 60],
        iconAnchor: [20, 60]
      });

      const marker = L.marker([cp.latitude, cp.longitude], { icon: customIcon }).addTo(map);

      marker.on('click', () => {
        sounds.playClick();
        if (isActive) {
          // Check if player inside geofence
          if (currentPosition) {
            const check = isInsideGeofence(
              currentPosition.latitude,
              currentPosition.longitude,
              cp.latitude,
              cp.longitude,
              cp.radiusMeters,
              boostMeters
            );
            if (check.inside) {
              onEnterCheckpoint(cp);
            } else {
              alert(`You are ${check.distance}m away from ${cp.name}. Get within ${check.effectiveRadius}m to enter!`);
            }
          }
        }
      });

      checkpointMarkersRef.current[cp.id] = { marker, circle };
    });
  }, [checkpoints, participant.currentStage, participant.completedStages, boostMeters, currentPosition]);

  // Update Player Position Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !currentPosition) return;

    const latLng: [number, number] = [currentPosition.latitude, currentPosition.longitude];

    if (!playerMarkerRef.current) {
      // Create Player Marker
      const playerIcon = L.divIcon({
        className: 'player-radar-marker',
        html: `
          <div class="relative w-8 h-8 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center">
            <span class="absolute w-10 h-10 rounded-full bg-cyan-400/30 animate-ping"></span>
            <span class="absolute w-6 h-6 rounded-full bg-cyan-500/40"></span>
            <div class="relative w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-lg flex items-center justify-center">
              <div class="w-1.5 h-1.5 rounded-full bg-slate-950"></div>
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      playerMarkerRef.current = L.marker(latLng, { icon: playerIcon, zIndexOffset: 1000 }).addTo(map);
    } else {
      playerMarkerRef.current.setLatLng(latLng);
    }

    if (!playerAccuracyCircleRef.current) {
      playerAccuracyCircleRef.current = L.circle(latLng, {
        radius: Math.max(currentPosition.accuracy || 10, 8),
        color: '#06b6d4',
        fillColor: '#06b6d4',
        fillOpacity: 0.12,
        weight: 1
      }).addTo(map);
    } else {
      playerAccuracyCircleRef.current.setLatLng(latLng);
      playerAccuracyCircleRef.current.setRadius(Math.max(currentPosition.accuracy || 10, 8));
    }
  }, [currentPosition]);

  // Recenter map on player or active checkpoint
  const handleRecenter = () => {
    sounds.playClick();
    const map = mapInstanceRef.current;
    if (!map) return;
    if (currentPosition) {
      map.flyTo([currentPosition.latitude, currentPosition.longitude], 18, { duration: 0.8 });
    } else {
      map.flyTo([activeCheckpoint.latitude, activeCheckpoint.longitude], 18, { duration: 0.8 });
    }
  };

  const handleZoomIn = () => {
    sounds.playClick();
    mapInstanceRef.current?.zoomIn();
  };

  const handleZoomOut = () => {
    sounds.playClick();
    mapInstanceRef.current?.zoomOut();
  };

  // Teleport directly to active checkpoint (GPS simulator for instant testing)
  const handleTeleportToActive = () => {
    sounds.playCorrect();
    // Put coordinates slightly inside checkpoint center (e.g. +3 meters)
    const newPos: GPSPosition = {
      latitude: activeCheckpoint.latitude + 0.00002,
      longitude: activeCheckpoint.longitude + 0.00002,
      accuracy: 5,
      timestamp: Date.now(),
      isSimulated: true
    };
    onPositionUpdate(newPos, true);

    const map = mapInstanceRef.current;
    if (map) {
      map.flyTo([newPos.latitude, newPos.longitude], 18, { duration: 0.5 });
    }
  };

  // Walk slightly closer
  const handleWalkCloser = () => {
    sounds.playClick();
    if (!currentPosition) {
      handleTeleportToActive();
      return;
    }
    // Interpolate 50% closer to active checkpoint
    const newLat = currentPosition.latitude + (activeCheckpoint.latitude - currentPosition.latitude) * 0.5;
    const newLon = currentPosition.longitude + (activeCheckpoint.longitude - currentPosition.longitude) * 0.5;

    const newPos: GPSPosition = {
      latitude: newLat,
      longitude: newLon,
      accuracy: 5,
      timestamp: Date.now(),
      isSimulated: true
    };
    onPositionUpdate(newPos, true);
  };

  // Start real browser geolocation watcher
  const handleRequestRealGps = () => {
    sounds.playClick();
    if (!navigator.geolocation) {
      setGeoError("Geolocation is not supported by your browser.");
      return;
    }

    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const realPos: GPSPosition = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          timestamp: pos.timestamp,
          isSimulated: false
        };
        onPositionUpdate(realPos, false);
        sounds.playCorrect();
      },
      (err) => {
        setGeoError(`Location error: ${err.message}. Use Simulator Mode for testing!`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  return (
    <div className="relative w-full h-[52vh] sm:h-[58vh] rounded-3xl overflow-hidden border border-cyan-900/40 shadow-2xl bg-slate-950">
      {/* Map Leaflet Container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Top Overlay: Active Mission Banner */}
      <div className="absolute top-3 left-3 right-3 z-10 pointer-events-none flex flex-col gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md border border-cyan-500/40 rounded-2xl p-2.5 sm:p-3 shadow-xl pointer-events-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-xl shrink-0">
              {activeCheckpoint.characterAvatar}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                  STAGE {activeCheckpoint.stageNumber}/5
                </span>
                <span className="text-slate-400 text-[10px]">•</span>
                <span className="text-[11px] text-slate-300 font-medium truncate">
                  {activeCheckpoint.name}
                </span>
              </div>
              <p className="text-xs font-semibold text-white truncate">
                {activeCheckpoint.shortLocation}
              </p>
            </div>
          </div>

          {/* Distance & Action */}
          <div className="shrink-0 flex items-center gap-2">
            {activeDistance ? (
              <div className="text-right">
                <div className={`text-xs sm:text-sm font-extrabold font-mono ${
                  activeDistance.inside ? 'text-emerald-400' : 'text-amber-400'
                }`}>
                  {activeDistance.inside ? 'IN GEOFENCE!' : `${activeDistance.distance}m away`}
                </div>
                <div className="text-[10px] text-slate-400">
                  Radius: {activeDistance.effectiveRadius}m
                </div>
              </div>
            ) : (
              <span className="text-xs text-slate-400">Locating...</span>
            )}

            {activeDistance?.inside ? (
              <button
                onClick={() => {
                  sounds.playCorrect();
                  onEnterCheckpoint(activeCheckpoint);
                }}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all animate-pulse"
              >
                ENTER CHALLENGE
              </button>
            ) : null}
          </div>
        </div>

        {/* GPS mode pill / error notification */}
        {geoError && (
          <div className="bg-rose-950/90 backdrop-blur-md border border-rose-800 rounded-xl p-2 text-rose-200 text-xs flex items-center gap-2 pointer-events-auto shadow-lg">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="truncate">{geoError}</span>
          </div>
        )}
      </div>

      {/* Bottom Floating Bar: Simulator Controls & Recenter */}
      <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between gap-2 pointer-events-none">
        {/* Simulator controls pill */}
        <div className="bg-slate-900/90 backdrop-blur-md border border-slate-700 rounded-2xl p-1.5 sm:p-2 shadow-xl pointer-events-auto flex items-center gap-1.5 sm:gap-2">
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-950 text-[10px] font-mono font-bold text-slate-300 border border-slate-800">
            <span className={`w-2 h-2 rounded-full ${isSimulated ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
            <span>{isSimulated ? 'SIMULATOR GPS' : 'REAL GPS'}</span>
          </div>

          <button
            onClick={handleTeleportToActive}
            className="px-2.5 py-1 rounded-xl bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 text-[11px] font-semibold transition flex items-center gap-1"
            title="Instant Teleport inside geofence for testing"
          >
            <Zap className="w-3 h-3 text-cyan-400" />
            <span>Teleport Here</span>
          </button>

          <button
            onClick={handleWalkCloser}
            className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition hidden sm:inline-flex items-center gap-1"
            title="Walk 50% closer"
          >
            <Navigation className="w-3 h-3 text-slate-400" />
            <span>Step Closer</span>
          </button>

          <button
            onClick={handleRequestRealGps}
            className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition flex items-center gap-1"
            title="Switch to Real Device GPS"
          >
            <Compass className="w-3 h-3 text-slate-400" />
            <span>Real GPS</span>
          </button>
        </div>

        {/* Right side floating controls: Zoom, Layer Switcher & Recenter */}
        <div className="flex items-center gap-1.5 relative pointer-events-auto shrink-0">
          {/* Zoom In & Out pill */}
          <div className="flex items-center rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-700 shadow-xl overflow-hidden divide-x divide-slate-800">
            <button
              onClick={handleZoomIn}
              className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center text-slate-300 hover:text-cyan-400 hover:bg-slate-800 transition active:scale-95"
              title="Zoom In"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={handleZoomOut}
              className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center text-slate-300 hover:text-cyan-400 hover:bg-slate-800 transition active:scale-95"
              title="Zoom Out"
            >
              <Minus className="w-4 h-4" />
            </button>
          </div>

          {/* Layer switcher popup */}
          {showLayerMenu && (
            <div className="absolute bottom-12 right-10 bg-slate-900/95 backdrop-blur-md border border-cyan-800 rounded-2xl p-2 shadow-2xl w-48 space-y-1 z-30 animate-in fade-in zoom-in-95">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1 block">
                Map Basemap Style
              </span>
              {(Object.keys(MAP_LAYERS) as MapTileStyle[]).map((styleId) => {
                const opt = MAP_LAYERS[styleId];
                const isSelected = selectedLayerStyle === styleId;
                return (
                  <button
                    key={styleId}
                    onClick={() => {
                      sounds.playClick();
                      setSelectedLayerStyle(styleId);
                      setShowLayerMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-cyan-950 text-cyan-200 border border-cyan-500 font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{opt.name}</span>
                    {isSelected && <span className="text-cyan-400 text-xs">✓</span>}
                  </button>
                );
              })}
            </div>
          )}

          {/* Layer switcher toggle button */}
          <button
            onClick={() => {
              sounds.playClick();
              setShowLayerMenu(!showLayerMenu);
            }}
            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-slate-900/90 backdrop-blur-md border shadow-xl flex items-center justify-center transition active:scale-95 ${
              showLayerMenu ? 'border-cyan-400 text-cyan-300' : 'border-slate-700 text-slate-300 hover:text-cyan-400 hover:bg-slate-800'
            }`}
            title="Switch Map Layers (CARTO Dark, Voyager, OSM, Satellite)"
          >
            <Layers className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Recenter button */}
          <button
            onClick={handleRecenter}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-700 text-cyan-400 hover:text-cyan-300 hover:bg-slate-800 shadow-xl flex items-center justify-center transition active:scale-95"
            title="Recenter Map"
          >
            <Crosshair className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

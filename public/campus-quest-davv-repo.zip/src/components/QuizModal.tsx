import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Checkpoint, Question, Participant, QuestionOption } from '../types/game';
import { FINAL_MOTIVATION_QUESTION } from '../config/defaultData';
import { sounds } from '../services/soundEffects';
import { 
  Heart, 
  HelpCircle, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Zap, 
  Lightbulb, 
  ArrowRight,
  ShieldAlert,
  KeyRound
} from 'lucide-react';

interface QuizModalProps {
  checkpoint: Checkpoint;
  questions: Question[];
  participant: Participant;
  onAnswerSubmit: (
    isCorrect: boolean, 
    questionIndex: number, 
    remainingLives: number, 
    isStageComplete: boolean
  ) => void;
  onStageFailed: (stageNumber: number) => void;
  onStageSuccess: (stageNumber: number, fragmentCode: string) => void;
  onConsumeHint: () => boolean;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  checkpoint,
  questions,
  participant,
  onAnswerSubmit,
  onStageFailed,
  onStageSuccess,
  onConsumeHint,
  onClose
}) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [lives, setLives] = useState(participant.lives || 3);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isLastAnswerCorrect, setIsLastAnswerCorrect] = useState<boolean | null>(null);
  const [feedbackJoke, setFeedbackJoke] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [isFailed, setIsFailed] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Stage 5 Motivation Question State
  const [showMotivationQ, setShowMotivationQ] = useState(false);
  const [motivationAnswerId, setMotivationAnswerId] = useState<string | null>(null);
  const [motivationFeedback, setMotivationFeedback] = useState<string | null>(null);

  const currentQuestion = questions[currentQIndex] || questions[0];
  const isLastQuestion = currentQIndex >= questions.length - 1;

  // Handle Option Click
  const handleSelectOption = (option: QuestionOption) => {
    if (isAnswerChecked || isFailed || isSuccess) return;
    sounds.playClick();
    setSelectedOptionId(option.id);
  };

  // Submit Answer
  const handleConfirmAnswer = () => {
    if (!selectedOptionId || isAnswerChecked) return;

    const isCorrect = selectedOptionId === currentQuestion.correctAnswerId;
    setIsAnswerChecked(true);
    setIsLastAnswerCorrect(isCorrect);

    if (isCorrect) {
      sounds.playCorrect();
      setFeedbackJoke(null);

      // Check if this is the final question of the stage
      if (isLastQuestion) {
        // If stage 5 (GDG Head), show final motivation question!
        if (checkpoint.stageNumber === 5) {
          setShowMotivationQ(true);
        } else {
          handleTriggerStageSuccess();
        }
      }
    } else {
      // Wrong answer
      sounds.playWrong();
      const newLives = Math.max(0, lives - 1);
      setLives(newLives);

      // Pick funny compiler joke
      const jokes = [
        "Access denied! Your answer failed to compile.",
        "Bhai, itna confidence aur output galat?",
        "Wrong output. Please update your brain's firmware.",
        "Shabash! Compiler bhi tumse explanation maang raha hai.",
        "Request rejected. Your logic is currently under maintenance.",
        "Interesting answer. Confidence toh hai, bas logic vacation par hai.",
        "Ye logic dekh ke compiler ne sick leave maang li."
      ];
      const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
      setFeedbackJoke(randomJoke);

      if (newLives <= 0) {
        setIsFailed(true);
        sounds.playWrong();
      }
    }

    onAnswerSubmit(isCorrect, currentQIndex, isCorrect ? lives : Math.max(0, lives - 1), isCorrect && isLastQuestion);
  };

  // Trigger Stage Success & Confetti
  const handleTriggerStageSuccess = () => {
    setIsSuccess(true);
    sounds.playStageComplete();
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  // Next Question
  const handleNextQuestion = () => {
    sounds.playClick();
    setIsAnswerChecked(false);
    setSelectedOptionId(null);
    setIsLastAnswerCorrect(null);
    setFeedbackJoke(null);
    setShowHint(false);
    setCurrentQIndex(prev => prev + 1);
  };

  // Use Hint Power-Up
  const handleUseHint = () => {
    const success = onConsumeHint();
    if (success) {
      sounds.playCorrect();
      setShowHint(true);
    } else {
      sounds.playWrong();
      alert("No Hint Reveal charges left! Earn more by completing checkpoints or time bonuses.");
    }
  };

  // Stage 5 Motivation Option Selected
  const handleSelectMotivation = (optId: string) => {
    sounds.playCorrect();
    setMotivationAnswerId(optId);
    const feedback = (FINAL_MOTIVATION_QUESTION.responses as Record<string, string>)[optId] || "Great choice!";
    setMotivationFeedback(feedback);
  };

  const handleFinishMotivationAndComplete = () => {
    sounds.playClick();
    setShowMotivationQ(false);
    handleTriggerStageSuccess();
  };

  // Retry from 0 lives
  const handleRetryStage = () => {
    sounds.playClick();
    onStageFailed(checkpoint.stageNumber);
  };

  // Finish and claim fragment
  const handleClaimFragmentAndContinue = () => {
    sounds.playCorrect();
    onStageSuccess(checkpoint.stageNumber, checkpoint.fragmentCode);
  };

  // ===================== STAGE 5 MOTIVATION MODAL =====================
  if (showMotivationQ) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
        <div className="w-full max-w-lg bg-slate-900 border-2 border-cyan-400 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-cyan-950/80 animate-in fade-in zoom-in-95">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-400 flex items-center justify-center text-2xl">
              🚀
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                FINAL LEVEL • NARRATIVE CHALLENGE
              </span>
              <h2 className="text-lg font-bold text-white">Ananya (GDG Head)</h2>
            </div>
          </div>

          <h3 className="text-base sm:text-lg font-bold text-white mb-4">
            "{FINAL_MOTIVATION_QUESTION.prompt}"
          </h3>

          <div className="space-y-2.5 mb-5">
            {FINAL_MOTIVATION_QUESTION.options.map((opt, idx) => (
              <button
                key={opt.id}
                onClick={() => handleSelectMotivation(opt.id)}
                className={`w-full p-3 rounded-2xl text-left border text-xs sm:text-sm font-medium transition-all ${
                  motivationAnswerId === opt.id
                    ? 'bg-cyan-950 text-cyan-200 border-cyan-400 shadow-md ring-1 ring-cyan-400'
                    : 'bg-slate-950/70 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-800'
                }`}
              >
                <span className="font-bold font-mono text-cyan-400 mr-2">{idx + 1}.</span>
                {opt.text}
              </button>
            ))}
          </div>

          {motivationFeedback && (
            <div className="bg-slate-950 border border-cyan-800/80 rounded-2xl p-4 mb-5 text-xs sm:text-sm text-cyan-200 italic leading-relaxed">
              <strong className="text-cyan-400 not-italic block mb-1">GDG Head:</strong>
              "{motivationFeedback}"
            </div>
          )}

          {motivationAnswerId && (
            <button
              onClick={handleFinishMotivationAndComplete}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-extrabold text-sm shadow-xl hover:scale-102 transition flex items-center justify-center gap-2"
            >
              <KeyRound className="w-4 h-4 text-slate-950" />
              <span>CLAIM THE 5TH FRAGMENT & KEY!</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // ===================== FAILED STAGE SCREEN =====================
  if (isFailed) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
        <div className="w-full max-w-lg bg-slate-900 border-2 border-rose-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-rose-950/50 animate-in fade-in zoom-in-95">
          <div className="text-center mb-5">
            <div className="w-16 h-16 rounded-2xl bg-rose-950/80 border-2 border-rose-500 flex items-center justify-center text-3xl mx-auto mb-3 shadow-lg">
              💔
            </div>
            <span className="inline-block px-3 py-1 rounded-full bg-rose-950 border border-rose-800 text-rose-300 text-xs font-bold uppercase tracking-wider mb-2">
              OUT OF LIVES (0/3)
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Stage Attempt Failed!
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              {checkpoint.characterName} sends you away with a lesson in debugging.
            </p>
          </div>

          <div className="bg-slate-950 border border-rose-900/50 rounded-2xl p-4 sm:p-5 mb-6 text-xs sm:text-sm text-rose-200 italic leading-relaxed">
            <span className="font-bold text-rose-400 not-italic block mb-1">
              {checkpoint.characterName}:
            </span>
            "{checkpoint.failureDialogue?.text || "Compilation failed. Go back and review your fundamentals!"}"
          </div>

          <div className="space-y-3">
            <button
              onClick={handleRetryStage}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 text-slate-950 font-black text-sm sm:text-base shadow-lg shadow-rose-500/20 hover:scale-[1.01] active:scale-[0.99] transition flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4 stroke-[3]" />
              <span>
                {checkpoint.stageNumber === 2 
                  ? "Report to Gatekeeper (Story Scolding)"
                  : `RETRY ${checkpoint.name.toUpperCase()} (RESTORE 3 LIVES)`}
              </span>
            </button>

            <button
              onClick={onClose}
              className="w-full py-2.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
            >
              Return to Campus Map
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ===================== STAGE SUCCESS & FRAGMENT REVEAL =====================
  if (isSuccess) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
        <div className="w-full max-w-lg bg-slate-900 border-2 border-emerald-400 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-emerald-950/50 animate-in fade-in zoom-in-95 text-center">
          
          <div className="w-16 h-16 rounded-2xl bg-emerald-950/80 border-2 border-emerald-400 flex items-center justify-center text-3xl mx-auto mb-3 shadow-lg shadow-emerald-500/30">
            🎉
          </div>

          <span className="inline-block px-3 py-1 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-2">
            STAGE {checkpoint.stageNumber} COMPLETED! • +100 PTS
          </span>

          <h2 className="text-xl sm:text-2xl font-black text-white mb-2">
            Challenge Cleared!
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 mb-5">
            "{checkpoint.successDialogue?.text}"
          </p>

          {/* Code Fragment Card */}
          <div className="bg-gradient-to-br from-slate-950 to-emerald-950/60 border-2 border-dashed border-emerald-400 rounded-2xl p-5 mb-6">
            <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
              SECRET REWARD DISCOVERED
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-widest my-1 drop-shadow-[0_0_8px_rgba(52,211,153,0.6)]">
              {checkpoint.fragmentText}
            </div>
            <span className="text-xs text-slate-400">
              {checkpoint.fragmentName}
            </span>
          </div>

          {/* Continue button */}
          <button
            onClick={handleClaimFragmentAndContinue}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500 text-slate-950 font-black text-sm sm:text-base shadow-xl shadow-emerald-500/30 hover:scale-102 active:scale-98 transition flex items-center justify-center gap-2"
          >
            <span>CONTINUE TO NEXT DESTINATION</span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      </div>
    );
  }

  // ===================== ACTIVE QUESTION SCREEN =====================
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-xl bg-slate-900 border border-cyan-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl shadow-cyan-950/70 animate-in fade-in zoom-in-95 max-h-[92vh] overflow-y-auto">
        
        {/* Top Header: Character, Stage & Lives */}
        <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-400 flex items-center justify-center text-2xl">
              {checkpoint.characterAvatar}
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>{checkpoint.characterName}</span>
                <span className="text-slate-500">•</span>
                <span className="text-cyan-400 font-mono">Stage {checkpoint.stageNumber}/5</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Question {currentQIndex + 1} of {questions.length}
              </div>
            </div>
          </div>

          {/* Lives Counter & Hint Power-Up */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleUseHint}
              disabled={showHint}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 border transition ${
                showHint
                  ? 'bg-amber-950/80 text-amber-300 border-amber-600'
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-400 border-slate-700'
              }`}
              title="Use Hint Reveal Power-Up"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] hidden xs:inline">Hint ({participant.powerUps.hint_reveal || 0})</span>
            </button>

            <div className="flex items-center gap-1 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-rose-950">
              {[1, 2, 3].map((heart) => (
                <span
                  key={heart}
                  className={`text-sm transition-all duration-200 ${
                    heart <= lives ? 'opacity-100 scale-100' : 'opacity-20 grayscale scale-75'
                  }`}
                >
                  ❤️
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-950 rounded-full h-1.5 mb-4 overflow-hidden border border-slate-800">
          <div
            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 transition-all duration-300"
            style={{ width: `${((currentQIndex + 1) / questions.length) * 100}%` }}
          />
        </div>

        {/* Question Prompt */}
        <div className="mb-4">
          <h3 className="text-sm sm:text-base font-bold text-white whitespace-pre-line leading-snug">
            {currentQuestion.prompt}
          </h3>

          {/* Hint reveal box */}
          {showHint && (
            <div className="mt-3 p-3 rounded-xl bg-amber-950/50 border border-amber-700/60 text-amber-200 text-xs flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-amber-300">CLUE:</strong>
                {currentQuestion.hint}
              </div>
            </div>
          )}
        </div>

        {/* Five Answer Options (Strictly 5 options) */}
        <div className="space-y-2 mb-4">
          {currentQuestion.options.map((option, idx) => {
            const isSelected = selectedOptionId === option.id;
            const isCorrectOption = option.id === currentQuestion.correctAnswerId;

            let btnStyle = 'bg-slate-950/80 text-slate-200 border-slate-800 hover:border-slate-700 hover:bg-slate-800/80';

            if (isAnswerChecked) {
              if (isCorrectOption) {
                btnStyle = 'bg-emerald-950/90 text-emerald-200 border-emerald-400 ring-1 ring-emerald-400 font-bold';
              } else if (isSelected && !isCorrectOption) {
                btnStyle = 'bg-rose-950/90 text-rose-200 border-rose-500 font-bold';
              } else {
                btnStyle = 'bg-slate-950/40 text-slate-500 border-slate-900 opacity-40';
              }
            } else if (isSelected) {
              btnStyle = 'bg-cyan-950 text-cyan-200 border-cyan-400 ring-1 ring-cyan-400 font-bold';
            }

            return (
              <button
                key={option.id}
                onClick={() => handleSelectOption(option)}
                disabled={isAnswerChecked}
                className={`w-full p-3 rounded-2xl text-left border text-xs sm:text-sm transition-all flex items-start gap-2.5 ${btnStyle}`}
              >
                <span className="font-mono font-bold text-cyan-400 shrink-0 mt-0.5">
                  {String.fromCharCode(65 + idx)}.
                </span>
                <span className="flex-1 leading-relaxed">{option.text}</span>
                {isAnswerChecked && isCorrectOption && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                )}
                {isAnswerChecked && isSelected && !isCorrectOption && (
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback Joke on Wrong Answer */}
        {feedbackJoke && (
          <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-700/80 text-rose-200 text-xs sm:text-sm font-medium mb-4 flex items-start gap-2.5 animate-in fade-in">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-rose-300 block mb-0.5">COMPILER HUMOR:</span>
              "{feedbackJoke}"
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center justify-between gap-3 pt-2">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Leave
          </button>

          {!isAnswerChecked ? (
            <button
              onClick={handleConfirmAnswer}
              disabled={!selectedOptionId}
              className={`px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md ${
                selectedOptionId
                  ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-cyan-500/25 hover:scale-102 active:scale-98'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              CONFIRM ANSWER
            </button>
          ) : (
            <button
              onClick={handleNextQuestion}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-extrabold text-xs sm:text-sm shadow-md hover:scale-102 active:scale-98 transition flex items-center gap-1.5"
            >
              <span>{isLastQuestion ? 'FINISH STAGE' : 'NEXT QUESTION'}</span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
